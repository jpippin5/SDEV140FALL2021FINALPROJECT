"""
Program:  SNAKEY
Author:  Joseph Pippin
A GUI snake game application.
1.  Significant constants
    None
2.  The input is
    Clicks on tkinter buttons
    Keypresses on directional keys
3.  Computations

4.  The output is
    a GUI display of snake game.
"""

#  Neccessary imports
from tkinter import *
from random import randint

#  Define and initialize global constants
global cntrlWinOpen, gmWinOpen
cntrlWinOpen = False  #  Whether the control window is open
gmWinOpen = False  #  Whether the game window is open

#  Represents the root window
class rtWin(Tk):

    #  Constructor creates root window
    def __init__(self):
        Tk.__init__(self)
        self.geometry("300x300")
        self.title("SNAKEY")
        self.resizable(False, False)
        
        #  Create the widgets of the root window
        logoFrm = Frame(self, width=300, height=150)  #  Logo frame
        logoFrm.place(x=0, y=0)        
        try:
            self.logoImg = PhotoImage(file=("SNAKEYlogo.gif"))  #  Image to use as logo       
            logoLbl = Label(logoFrm, image=self.logoImg)  #  Label for logo
            logoLbl.pack(fill=BOTH)
        except TclError:
            logoLbl = Label(self, text="SNAKEY", pady=75, padx=130)  #  Label if logo image not found
            logoLbl.place(x=0, y=0)

        toGameBtn = Button(self, text="Play", command=self.toGame, width=10, height=2)  #  Button to send to game window
        toGameBtn.place(x=110, y=157)

        toCntrlBtn = Button(self, text="Controls", command=self.toControls, width=10, height=2)  #  Button to send to control window
        toCntrlBtn.place(x=110, y=204)

        Button(self, text="Exit Game", command=self.toExit, width=10, height=2).place(x=110, y=251)  #  Button to close SNAKEY app
  
    #  Definition for when game window button clicked on root window
    def toGame(self):
        global gmWinOpen
        if gmWinOpen == True:  #  Button won't do anything if game window is open
            pass
        if gmWinOpen == False:  #  Button will open game window if it is not already open
            gmWinOpen = True
            self.gmWindow(self)

    #  Definition for when control window button clicked on root window
    def toControls(self):
        global cntrlWinOpen        
        if cntrlWinOpen == True:  #  Button won't do anything if control window is open          
            pass
        elif cntrlWinOpen == False:  #  Button will open control window if it is not already open
            cntrlWinOpen = True
            self.cntrlWin(self)       

    #  Definition for when exit button clicked on root window
    def toExit(self):
        rtWin.quit(self)   

    #  Represents the game window
    class gmWindow(Toplevel):

        #  Constructor creates game window
        def __init__(self, parent):
            super().__init__(parent)
            self.geometry("400x300")
            self.title("SNAKEY")
            self.resizable(False, False)
            self.focus_set()  #  Focuses on game window when created
            self.protocol("WM_DELETE_WINDOW", self.toExit)  #  Sends to toExit when window is closed by x button

            #  Define move events for inputs
            def moveUp(event):
                self.input = "up"
                self.gs = True
            
            def moveDown(event):
                self.input = "down"
                self.gs = True

            def moveLeft(event):
                self.input = "left"
                self.gs = True

            def moveRight(event):
                self.input = "right"
                self.gs = True

            #  Bind directional arrow keys to their events for inputs
            self.bind("<Up>", moveUp)
            self.bind("<Down>", moveDown)
            self.bind("<Left>", moveLeft)
            self.bind("<Right>", moveRight)

            #  The gameloop
            def gameloop():                
                if self.gs == False:  #  If gameStart is false, wait for input to start game
                    self.after(100, gameloop)                
                else:  #  If gameStart is true, go on
                    if self.go == True:  #  If gameOver is true, current game is done so wait for input to start new game from newGameStart button click                                  
                        self.after(100, gameloop)
                    else:  #  gameStart is true and gameOver is false, so continue gameloop
                        self.instructionLbl.config(text="Use directional\narrows to\ncontrol\nthe snake.\nGet the apple.")  #  Show instructions on instruction label
                        self.fSnakePos = []  #  Clear the futute snake position
                        
                        #  Update move direction if a valid input, cannot move backwards into own self
                        if self.move == "":
                            self.move = self.input
                        if (self.move == "up" or self.move == "down") and (self.input == "left" or self.input == "right"):
                                self.move = self.input
                        if (self.move == "left" or self.move == "right") and (self.input == "up" or self.input == "down"):
                                self.move = self.input

                        #  Find future snake position
                        self.fSnakePos.append(self.futurePos())  #  Gets first new position
                        if len(self.snakePos) > 1:  #  Fills in rest of positions
                            for x in self.snakePos[0:-1]:
                                self.fSnakePos.append(x)            
                        
                        #  Check for snake body collisions
                        for x in self.fSnakePos[1:]:
                            if x[0] == self.fSnakePos[0][0] and x[1] == self.fSnakePos[0][1]:
                                self.gameOver()  #  Game is over

                        #  Check for wall collisions
                        if self.fSnakePos[0][0] < 0 or self.fSnakePos[0][0] > 19:
                            self.gameOver()  #  Game is over
                        if self.fSnakePos[0][1] < 0 or self.fSnakePos[0][1] > 19:
                            self.gameOver()  #  Game is over

                        #  If future position does not game over
                        if self.go == False:
                            #  Check if apple eaten
                            if self.fSnakePos[0] == self.applePos[0]:
                                self.score += 1  #  Update score
                                self.scoreLbl.config(text=self.score)
                                self.applePos = []  #  Clear apple positon
                                self.applePos.append(self.newApplePos(self.snakePos, self.fSnakePos))  #  Find new apple position
                                Frame(self.arena, width=15, height=15, background="red").place(x=self.applePos[0][0]*15, y=self.applePos[0][1]*15)  #  Place new apple
                                self.snakeTailPos = self.fSnakePos[-1]  #  Get position to add new snake tail to body
                                self.appleEaten = True  #  Apple eaten on this game frame, will reset next frame and add snake tail to body
                            
                            #  Clear snake position
                            self.snakePos = []

                            #  Update snake postion
                            for x in self.fSnakePos:
                                self.snakePos.append(x)

                            #  Update snake if apple eaten, nextTurn is set to false on new game, so this will cause snake to advance one position to add snake tail at end of snake body on next game frame
                            if self.appleEaten == True:
                                if self.nextTurn == True:
                                    self.nextTurn = False
                                    self.snakePos.append(self.snakeTailPos)
                                    self.appleEaten = False
                                else:
                                    self.nextTurn = True            
                                
                            #  Clear arena frame of previous game frame
                            for x in self.arena.winfo_children():
                                x.destroy()

                            #  Draw new snake and apple
                            for item in self.snakePos:
                                Frame(self.arena, width=15, height=15, background="green").place(x=item[0]*15, y=item[1]*15)
                            Frame(self.arena, width=15, height=15, background="red").place(x=self.applePos[0][0]*15, y=self.applePos[0][1]*15)                           

                        #  Call gameloop for next game frame                    
                        self.after(100, gameloop)

            self.createGmBoard()  #  Call to create the game board window
            self.newGameStart()  #  Call to create a new game initially
            gameloop()  #  Initial entrance of game loop

        #  Define what happens when game is over
        def gameOver(self):               
            self.gs = False
            self.go = True
            self.instructionLbl.config(text=("GAME OVER.\n\nClick Start\nNew Game\nbutton to\nplay again."))

        #  Define what happens when the next game frame move is to be calculated
        def futurePos(self):                
            if self.move == "up":
                x = self.snakePos[0][0]
                y = self.snakePos[0][1] - 1                    
                return [x, y]
            elif self.move == "down":
                x = self.snakePos[0][0]
                y = self.snakePos[0][1] + 1                
                return [x, y]
            elif self.move == "right":
                x = self.snakePos[0][0] + 1
                y = self.snakePos[0][1]                    
                return [x, y]
            elif self.move == "left":
                x = self.snakePos[0][0] - 1
                y = self.snakePos[0][1]                    
                return [x, y]
        
        #  Define how a new snake position is determined
        def newGameSnakePos(self):
                x = randint(0, 19)
                y = randint(0, 19)
                return [x,y]
        
        #  Define how a new apple position is determined
        def newApplePos(self, y, z):
                x = [randint(0,19), randint(0,19)]  #  Randomly get new apple x and y position
                if x in y or x in z:                    
                    return self.newApplePos(y)  #  If new apple x and y matches a snake position, resend to newApplePos for new apple postion
                else:
                    return x

        #  Define what happens when new game is to be started
        def newGameStart(self):
                self.input = ""  #  Input received be keys
                self.move = ""  #  Move to be down next, determined by previous move and next input
                self.gs = False  #  Is game ok to start
                self.go = False  #  Is the game over
                self.fSnakePos = []  #  Future snake position
                self.snakePos = []  #  Current snake position
                self.applePos = []  #  Apple position
                self.score = 0  #  Score
                self.snakeTailPos = []  #  Position of snakes tail, the last position of future snake position
                self.appleEaten = False  #  Is the apple eaten on this game frame
                self.nextTurn = False  #  Used as a one frame wait to load new snake tail when apple is eaten
                
                #  Clears game window arena for new game
                for x in self.arena.winfo_children():
                    x.destroy()
                self.scoreLbl.config(text=self.score)  #  Reset game score
                self.snakePos.append(self.newGameSnakePos())  #  Get new snake position                
                self.applePos.append(self.newApplePos(self.snakePos, self.fSnakePos))  #  Get new apple postion
                Frame(self.arena, width=15, height=15, background="green").place(x=self.snakePos[0][0]*15, y=self.snakePos[0][1]*15)  #  Place snake in arena
                Frame(self.arena, width=15, height=15, background="red").place(x=self.applePos[0][0]*15, y=self.applePos[0][1]*15)  #  Place apple in arena
                self.instructionLbl.config(text="Press any\ndirection\nkey to\nbegin.")  #  Update instructions lable

        #  Define what happens when game window board is to be created
        def createGmBoard(self):
                self.arena = Frame(self, width=300, height=300, background="tan")  #  Arena frame that snake and apple occupy
                self.arena.place(x=0, y=0)
                self.scoreTitleLabel = Label(self, text="SCORE")  #  Score title label
                self.scoreTitleLabel.place(x=325, y= 0)
                self.scoreLbl = Label(self, text="")  #  Score label
                self.scoreLbl.place(x=340, y=20)
                self.instructionLbl = Label(self, text="Press any\ndirection\nkey to\nbegin.")  #  Instructions label to indicate what to do
                self.instructionLbl.place(x=315, y=50)
                Button(self, text="Exit Game \nPage", width=10, height=2, command=self.toExit).place(x=310, y=251)  #  Button to close game window
                Button(self, text="Start New\nGame", width=10, height=2, command=self.newGameStart).place(x=310, y=201)  #  Button to start new SNAKEY game

        #  Define what is to happen when close game window button or x button is pressed
        def toExit(self):
            global gmWinOpen            
            gmWinOpen = False
            self.destroy()

    #  Represents the control window
    class cntrlWin(Toplevel):

        #  Constructor creates the control window
        def __init__(self, parent):
            super().__init__(parent)
            self.geometry("300x400")
            self.title("SNAKEY")
            self.resizable(False, False)
            self.focus_set()  #  Focuses on control window when created
            self.protocol("WM_DELETE_WINDOW", self.toExit)  #  Sends to toExit when window is closed by x button         

            #  Creates the widgets of the control window
            logoFrm = Frame(self, width=300, height=150)  #  Logo frame
            logoFrm.place(x=0, y=0)
            try:
                self.logoImg = PhotoImage(file=("SNAKEYlogo.gif"))  #  Image to be used as logo    
                logoLbl = Label(logoFrm, image=self.logoImg)  #  Label for logo
                logoLbl.pack(fill=BOTH)
            except TclError:
                logoLbl = Label(self, text="SNAKEY", pady=75, padx=130)  #  Label for logo in image not found
                logoLbl.place(x=0, y=0)

            controlLogoFrm = Frame(self, width=300, height=100)  #  Control widgets frame
            controlLogoFrm.place(x=0, y=150)
            controlLogoLbl = Label(controlLogoFrm, text=("CONTROLS"), font=("Arial", 25))  #  Label for control title/logo label
            controlLogoLbl.place(x=54,y=28)
            
            moveUpLbl = Label(self, text="Move Up", width=10, height=2)  #  Label for move up
            moveUpLbl.place(x=24, y=254)
            upFrm = Frame(self, width=50, height=50)  #  Frame for move up image
            upFrm.place(x=100, y=245)
            try:
                self.upArrowImg = PhotoImage(file=("upArrow.gif"))  #  Image for up arrow      
                logoLbl = Label(upFrm, image=self.upArrowImg)  #  Label for up arrow image
                logoLbl.place(x=0, y=0)
            except TclError:
                logoLbl = Label(upFrm, text="Up\nArrow", font=("Arial", 10), background="white")  #  Label if up arrow image not found
                logoLbl.place(x=0, y=0)
            
            moveDownLbl = Label(self, text="Move Down" , width=10, height=2)  #  Label for move down
            moveDownLbl.place(x=24, y=299)
            downFrm = Frame(self, width=50, height=50)  #  Frame for move down image
            downFrm.place(x=100, y=295)
            try:
                self.downArrowImg = PhotoImage(file=("downArrow.gif"))  #  Image for down arrow      
                logoLbl = Label(downFrm, image=self.downArrowImg)  #  Label for down arrow image
                logoLbl.place(x=0, y=0)
            except TclError:
                logoLbl = Label(downFrm, text="Down\nArrow", font=("Arial", 10), pady=10, background="white")  #  Label if down arrow image not found
                logoLbl.place(x=0, y=0)
            
            moveLeftLbl = Label(self, text="Move Left", width=10, height=2)  #  Label for move left
            moveLeftLbl.place(x=150, y=254)
            leftFrm = Frame(self, width=50, height=50)  #  Frame for move left image
            leftFrm.place(x=226, y=245)
            try:
                self.leftArrowImg = PhotoImage(file=("leftArrow.gif"))  #  Image for left arrow     
                logoLbl = Label(leftFrm, image=self.leftArrowImg)  #  Label for left arrow image
                logoLbl.place(x=0, y=0)
            except TclError:
                logoLbl = Label(leftFrm, text="Left\nArrow", font=("Arial", 10), pady=10, background="white")  #  Label if left arrow image not found
                logoLbl.place(x=0, y=0)
            
            moveRightLbl = Label(self, text="Move Right", width=10, height=2)  #  Label for move right
            moveRightLbl.place(x=150, y=299)
            rightFrm = Frame(self, width=50, height=50)  #  Frame for move right image
            rightFrm.place(x=226, y=295)
            try:
                self.rightArrowImg = PhotoImage(file=("rightArrow.gif"))  #  Image for right arrow
                logoLbl = Label(rightFrm, image=self.rightArrowImg)  #  Label for right arrow image
                logoLbl.place(x=0, y=0)
            except TclError:
                logoLbl = Label(rightFrm, text="Right\nArrow", font=("Arial", 10), pady=10, background="white")  #  Label if right arrow image not found
                logoLbl.place(x=0, y=0)

            exitControlsBtn = Button(self, text="Exit Controls Page", command=self.toExit, width=15, height=2)  #  Button to close control window
            exitControlsBtn.place(x=92, y=351)         

        #  Definition for when exitControls button or x button clicked
        def toExit(self):
            global cntrlWinOpen            
            cntrlWinOpen = False
            self.destroy()    

#  Definition of what to do if program is loaded to run
def main():
    rtWin().mainloop()

#  If program is to loaded to run, sends to main
if __name__ == "__main__":
    main()